/* Matemática ENEM: JavaScript puro. Progresso, XP, ofensiva e plano ficam salvos no navegador (localStorage). */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const store = {
  get(k, d) { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} }
};
const esc = s => s.replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const iso = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

let xp = store.get('xp', 0), feitos = store.get('feitos', []), dias = store.get('dias', []),
    plano = store.get('plano', {}), tema = store.get('tema', 'light'),
    caderno = store.get('caderno', []), xpDia = store.get('xpDia', {}), meta = store.get('meta', 50);
TOPICOS.forEach(t => t.qs.forEach((q, i) => q.k = t.id + ':' + i));   // identifica cada questão
const shuffle = a => a.map(x => [Math.random(), x]).sort((a, b) => a[0] - b[0]).map(x => x[1]);

/* ===== Estatísticas: ofensiva, XP, progresso ===== */
function marca() {                       // registra que hoje houve estudo
  const h = iso(new Date());
  if (!dias.includes(h)) dias.push(h);
  store.set('dias', dias); store.set('xp', xp); store.set('feitos', feitos);
  store.set('caderno', caderno); store.set('xpDia', xpDia);
  stats(); cal();
}
function stats() {
  let n = 0, d = new Date();
  if (!dias.includes(iso(d))) d.setDate(d.getDate() - 1);
  while (dias.includes(iso(d))) { n++; d.setDate(d.getDate() - 1); }
  $('#ofNum').textContent = n === 1 ? '1 dia' : n + ' dias';
  $('#sFogo').textContent = '🔥 ' + n; $('#sXp').textContent = '⭐ ' + xp; $('#xpNum').textContent = xp;
  $('#semana').innerHTML = [6, 5, 4, 3, 2, 1, 0].map(k => {
    const x = new Date(); x.setDate(x.getDate() - k);
    return `<span class="${dias.includes(iso(x)) ? 'on' : ''}">${'DSTQQSS'[x.getDay()]}</span>`;
  }).join('');
  $('#progtxt').textContent = `${feitos.length} de ${TOPICOS.length} lições concluídas`;
  $('#progbar').style.width = feitos.length / TOPICOS.length * 100 + '%';
  const xh = xpDia[iso(new Date())] || 0;                       // meta diária
  $('#metaTxt').textContent = xh >= meta ? `Meta batida! 🎯 ${xh} XP hoje` : `${xh} de ${meta} XP hoje`;
  $('#metaBar').style.width = Math.min(100, xh / meta * 100) + '%';
  $('#cadTxt').textContent = caderno.length ? `${caderno.length} questão(ões) para rever. Acertar tira do caderno.` : 'Nenhum erro por aqui. Continue assim!';
  $('#btnRev').disabled = !caderno.length;
  $('#trTxt').textContent = feitos.length ? '8 questões sorteadas das lições que você já concluiu.' : 'Conclua uma lição para liberar o treino.';
  $('#btnTreino').disabled = !feitos.length;
  const L = plano[iso(new Date())] || [];
  $('#hojeLista').innerHTML = L.length ? L.map(t => `<li>${t.ok ? '✓' : '•'} ${esc(t.t)}</li>`).join('') : '<li class="vazio">Nada planejado para hoje.</li>';
}

/* ===== Tema e navegação ===== */
function aplicaTema() {
  document.documentElement.dataset.theme = tema;
  $('#btnTema').textContent = tema === 'dark' ? '☀️ Modo dia' : '🌙 Modo noite';
}
$('#btnTema').onclick = () => { tema = tema === 'dark' ? 'light' : 'dark'; store.set('tema', tema); aplicaTema(); };
$$('.menu nav button').forEach(b => b.onclick = () => {
  $$('.menu nav button').forEach(x => x.classList.toggle('on', x === b));
  ['aprender', 'praticar', 'formulas', 'plano'].forEach(v => $('#' + v).hidden = v !== b.dataset.v);
});

/* ===== Trilha de aprendizado ===== */
function trilha() {
  $('#aprender').innerHTML = UNIDADES.map((u, ui) => `
    <section class="unidade" style="--c:${u.c};--cd:${u.cd}">
      <div class="ban"><div><small>Unidade ${ui + 1}</small><h2>${u.n}</h2></div><span>${u.d}</span></div>
      <div class="caminho">${TOPICOS.filter(t => t.u === ui).map((t, k) => {
        const i = TOPICOS.indexOf(t), feito = feitos.includes(t.id), livre = i === 0 || feitos.includes(TOPICOS[i - 1].id);
        return `<div class="no" style="transform:translateX(${[0, 46, 70, 46][k % 4]}px)">
          <button type="button" class="${feito ? 'feito' : livre ? '' : 'trava'}" data-t="${t.id}" ${livre ? '' : 'disabled'} aria-label="${t.n}">${feito ? '✓' : livre ? t.i : '🔒'}</button>
          <span>${t.n}</span>${livre && !feito ? '<em>COMEÇAR</em>' : ''}</div>`;
      }).join('')}</div>
    </section>`).join('');
}
$('#aprender').onclick = e => { const b = e.target.closest('button[data-t]'); if (b) licao(b.dataset.t); };

/* ===== Sessões: lição, revisão de erros e treino misto ===== */
function sessao(fila, aoFim, bonus, titulo = 'Lição concluída!', rev = false) {
  const L = $('#licao'), total = fila.length, qs = fila.filter(p => p.k === 'q').map(p => p.q);
  let ok = 0, ganho = 0, dicas = 0, acabou = false; const errou = new Set();
  L.hidden = false; document.body.classList.add('em-licao');

  const rod = (html, cls = '') => `<footer class="lrod ${cls}"><div class="rin">${html}</div></footer>`;
  const tela = (corpo, rodape) => {
    L.innerHTML = `<div class="ltopo">${acabou ? '' : '<button type="button" class="x" id="sair" aria-label="Sair">✕</button>'}<div class="barra"><i style="width:${ok / total * 100}%"></i></div></div><div class="lcorpo">${corpo}</div>${rodape}`;
    const s = $('#sair'); if (s) s.onclick = () => { if (confirm('Sair agora? O progresso desta sessão será perdido.')) fecha(); };
  };
  const fecha = () => { L.hidden = true; L.innerHTML = ''; document.body.classList.remove('em-licao'); trilha(); stats(); };
  const prox = () => { ok++; fila.shift(); passo(); };
  const continuar = '<span></span><button type="button" class="btn" id="go">Continuar</button>';

  function passo() {
    const p = fila[0]; dicas = 0;
    if (!p) return fim();
    if (p.k === 'v') {
      const t = p.t;   // para embutir um vídeo: coloque o ID do YouTube no campo "yt" do tópico em data.js
      tela(`<h1>Assista à aula</h1><div class="video">${t.yt ? `<iframe class="yt" src="https://www.youtube-nocookie.com/embed/${t.yt}" title="Videoaula" allowfullscreen loading="lazy"></iframe>` : '<div class="player" aria-hidden="true">▶</div>'}
        <p>Dois professores explicam <b>${t.n}</b>. Escolha um e volte para continuar.</p>
        ${t.v.map(([n, u]) => `<a class="btn alt" href="${u}" target="_blank" rel="noopener">▶ ${n}</a>`).join('')}</div>`, rod(continuar));
      $('#go').onclick = prox;
    } else if (p.k === 't') {
      tela(`<h1>${p.t.n}</h1>${p.t.t}<div class="ouro"><b>O que o ENEM mais cobra</b><p>${p.t.o}</p></div>`, rod(continuar));
      $('#go').onclick = prox;
    } else questao(p.q);
  }

  function questao(q) {
    let sel = -1;
    tela(`<h1>Escolha a resposta certa</h1><p class="enun">${q.e}</p>
      <div class="alts">${q.o.map((o, j) => `<button type="button" data-j="${j}"><b>${j + 1}</b>${o}</button>`).join('')}</div><div id="dicas"></div>
      <p class="atalho">Atalhos: teclas 1 a 4 escolhem a resposta e Enter confirma.</p>`,
      rod(`${q.d.length ? '<button type="button" class="btn alt" id="dica">💡 Dica</button>' : '<span></span>'}<button type="button" class="btn" id="ver" disabled>Verificar</button>`));
    $$('.alts button').forEach(b => b.onclick = () => {
      sel = +b.dataset.j; $$('.alts button').forEach(x => x.classList.toggle('sel', x === b)); $('#ver').disabled = false;
    });
    if (q.d.length) $('#dica').onclick = () => {          // cada dica revela um pouco mais
      $('#dicas').insertAdjacentHTML('beforeend', `<div class="dica">💡 ${q.d[dicas++]}</div>`);
      $('#dica').textContent = `💡 Dica ${dicas}/${q.d.length}`; if (dicas >= q.d.length) $('#dica').disabled = true;
    };
    $('#ver').onclick = () => {
      const certo = sel === q.c;
      $$('.alts button').forEach((b, j) => { b.disabled = true; b.classList.toggle('certa', j === q.c); b.classList.toggle('errada', j === sel && !certo); });
      if (certo && !errou.has(q)) ganho += 10;
      if (!certo && !caderno.includes(q.k)) caderno.push(q.k);                    // erro vai para o caderno
      if (certo && rev && !errou.has(q)) caderno = caderno.filter(k => k !== q.k); // revisão acertada sai do caderno
      const r = $('.lrod'); r.className = 'lrod ' + (certo ? 'ok' : 'ruim');
      r.innerHTML = `<div class="rin fb"><div><b>${certo ? 'Muito bem!' : 'Resposta correta: ' + q.o[q.c]}</b><div class="expl">${q.x}</div></div><button type="button" class="btn" id="go">Continuar</button></div>`;
      $('#go').onclick = () => { if (certo) prox(); else { errou.add(q); fila.push(fila.shift()); passo(); } };  // errou: volta no fim
    };
  }

  function fim() {
    const acertos = qs.filter(q => !errou.has(q)).length, hj = iso(new Date());
    ganho += bonus; xp += ganho; xpDia[hj] = (xpDia[hj] || 0) + ganho; aoFim();
    marca(); acabou = true;
    tela(`<div class="fim"><div class="trofeu">🎉</div><h1>${titulo}</h1>
      <div class="resumo"><div><b>⭐ ${ganho}</b><span>XP ganho</span></div><div><b>🎯 ${Math.round(acertos / qs.length * 100)}%</b><span>de acerto de primeira</span></div></div></div>`, rod(continuar));
    $('#go').onclick = fecha;
  }
  passo();
}
function licao(id) {
  const t = TOPICOS.find(x => x.id === id);
  sessao([{ k: 'v', t }, { k: 't', t }, ...t.qs.map(q => ({ k: 'q', q }))], () => { if (!feitos.includes(t.id)) feitos.push(t.id); }, 20);
}
$('#btnRev').onclick = () => {
  const todas = TOPICOS.flatMap(t => t.qs);
  sessao(shuffle(caderno.map(k => todas.find(q => q.k === k)).filter(Boolean)).slice(0, 10).map(q => ({ k: 'q', q })), () => {}, 10, 'Revisão concluída!', true);
};
$('#btnTreino').onclick = () => sessao(shuffle(TOPICOS.filter(t => feitos.includes(t.id)).flatMap(t => t.qs)).slice(0, 8).map(q => ({ k: 'q', q })), () => {}, 15, 'Treino concluído!');
document.addEventListener('keydown', e => {            // atalhos de teclado dentro da lição
  if ($('#licao').hidden) return;
  if (e.key === 'Enter') { e.preventDefault(); const b = $('#go') || $('#ver:not(:disabled)'); if (b) b.click(); }
  else if (/^[1-4]$/.test(e.key)) { const b = $$('.alts button')[+e.key - 1]; if (b && !b.disabled) b.click(); }
});

/* ===== Planejador (calendário) ===== */
let ref = new Date(), sel = iso(new Date()); ref.setDate(1);
$('#selTopico').innerHTML = TOPICOS.map(t => t.n).concat(['Revisão geral', 'Simulado']).map(t => `<option>${t}</option>`).join('');
function lista() {
  const L = plano[sel] || [];
  $('#diaTit').textContent = new Date(sel + 'T12:00').toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' });
  $('#listaDia').innerHTML = L.length ? L.map((t, i) => `<li class="${t.ok ? 'ok' : ''}"><label><input type="checkbox" data-i="${i}" ${t.ok ? 'checked' : ''}> ${esc(t.t)}</label><button type="button" data-x="${i}" aria-label="Remover">✕</button></li>`).join('') : '<li class="vazio">Nada planejado para este dia.</li>';
}
function cal() {
  const y = ref.getFullYear(), m = ref.getMonth(), hoje = iso(new Date());
  let h = ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'].map(d => `<b>${d}</b>`).join('') + '<i></i>'.repeat(new Date(y, m, 1).getDay());
  for (let d = 1, n = new Date(y, m + 1, 0).getDate(); d <= n; d++) {
    const k = iso(new Date(y, m, d)), c = (plano[k] || []).length;
    h += `<button type="button" data-d="${k}" class="${k === sel ? 'sel ' : ''}${dias.includes(k) ? 'estudou ' : ''}${k === hoje ? 'hoje' : ''}">${d}${c ? `<small>${c}</small>` : ''}</button>`;
  }
  $('#mesTit').textContent = ref.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
  $('#grade').innerHTML = h; lista();
}
const salva = () => { store.set('plano', plano); cal(); stats(); };
$('#grade').onclick = e => { const b = e.target.closest('button[data-d]'); if (b) { sel = b.dataset.d; cal(); } };
$('#mesAnt').onclick = () => { ref.setMonth(ref.getMonth() - 1); cal(); };
$('#mesProx').onclick = () => { ref.setMonth(ref.getMonth() + 1); cal(); };
$('#addTarefa').onclick = () => {
  const nota = $('#txtNota').value.trim();
  (plano[sel] = plano[sel] || []).push({ t: $('#selTopico').value + (nota ? ' · ' + nota : ''), ok: false });
  $('#txtNota').value = ''; salva();
};
$('#listaDia').onclick = e => { const x = e.target.closest('button[data-x]'); if (x) { plano[sel].splice(+x.dataset.x, 1); salva(); } };
$('#listaDia').onchange = e => { plano[sel][+e.target.dataset.i].ok = e.target.checked; salva(); if (e.target.checked) marca(); };

/* ===== Plano automático, meta e formulário ===== */
$('#diasSem').innerHTML = ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'].map((l, i) => `<label><input type="checkbox" value="${i}" ${[1, 3, 5].includes(i) ? 'checked' : ''}><span>${l}</span></label>`).join('');
$('#btnAuto').onclick = () => {
  const dow = $$('#diasSem input:checked').map(c => +c.value); if (!dow.length) return;
  const ja = new Set(Object.values(plano).flat().map(t => t.t));
  const pend = TOPICOS.filter(t => !feitos.includes(t.id) && !ja.has('Lição: ' + t.n));
  for (let d = new Date(), n = 0; pend.length && n < 365; d.setDate(d.getDate() + 1), n++)
    if (dow.includes(d.getDay())) (plano[iso(d)] = plano[iso(d)] || []).push({ t: 'Lição: ' + pend.shift().n, ok: false });
  salva();
};
$('#meta').value = meta; $('#meta').onchange = () => { meta = +$('#meta').value; store.set('meta', meta); stats(); };
$('#listaFormulas').innerHTML = TOPICOS.map(t => {
  const f = [...t.t.matchAll(/<div class="formula">(.*?)<\/div>/g)].map(m => `<div class="formula">${m[1]}</div>`).join('');
  return f ? `<div class="card"><h3>${t.n}</h3>${f}</div>` : '';
}).join('');

aplicaTema(); trilha(); cal(); stats();
