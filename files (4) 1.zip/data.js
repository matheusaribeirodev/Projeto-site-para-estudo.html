const UNIDADES = [{"n": "Aritmética", "d": "Proporção, porcentagem e estatística", "c": "#F97316", "cd": "#C2410C"}, {"n": "Matemática Básica", "d": "Frações, operações, MMC e MDC", "c": "#EF4444", "cd": "#B91C1C"}, {"n": "Geometria", "d": "Áreas, Pitágoras e volumes", "c": "#F59E0B", "cd": "#B45309"}, {"n": "Álgebra", "d": "Funções, exponencial e logaritmos", "c": "#EC4899", "cd": "#BE185D"}];
const TOPICOS = [
{
"id": "razao",
"n": "Razão e Proporção",
"u": 0,
"i": ":",
"v": [
[
"Ferretto Matemática",
"https://www.youtube.com/results?search_query=Ferretto+Matem%C3%A1tica+Raz%C3%A3o+e+Propor%C3%A7%C3%A3o+ENEM"
],
[
"Marcos Aba",
"https://www.youtube.com/results?search_query=Marcos+Aba+Raz%C3%A3o+e+Propor%C3%A7%C3%A3o+ENEM"
]
],
"t": "<p>Razão é a comparação entre duas grandezas por divisão. Proporção é a igualdade entre duas razões. Aparece em escalas, velocidade, densidade e receitas.</p><div class=\"formula\">Razão: a/b &nbsp;|&nbsp; Proporção: a/b = c/d ⇒ a·d = b·c</div>",
"o": "Escalas de mapas e plantas. A pegadinha quase sempre é a conversão de unidades (cm para m ou km).",
"qs": [
{
"e": "Em um mapa de escala 1:500.000, dois pontos estão a 4 cm. Qual é a distância real?",
"o": [
"2 km",
"20 km",
"200 km",
"2.000 km"
],
"c": 1,
"d": [
"Escreva a escala como razão: 1 cm no mapa equivale a 500.000 cm na realidade.",
"Multiplique a medida do mapa (4 cm) por 500.000.",
"O resultado está em cm. Divida por 100.000 para chegar em km."
],
"x": "<ol>\n            <li>A escala diz que 1 cm no mapa equivale a 500.000 cm reais.</li>\n            <li>Multiplique: 4 × 500.000 = 2.000.000 cm.</li>\n            <li>Converta: 2.000.000 cm = 20.000 m = 20 km.</li>\n          </ol><p class=\"resposta\">Resposta: 20 km.</p>"
},
{
"e": "Em uma receita, a razão entre farinha e açúcar é 3:2. Com 600 g de farinha, quantos gramas de açúcar?",
"o": [
"300 g",
"400 g",
"900 g",
"1.200 g"
],
"c": 1,
"d": [],
"x": "3/2 = 600/x, então x = 400."
},
{
"e": "Um carro percorre 180 km em 2 h. Mantida a velocidade, quantos km percorre em 5 h?",
"o": [
"360 km",
"400 km",
"450 km",
"500 km"
],
"c": 2,
"d": [],
"x": "Velocidade = 90 km/h. Em 5 h: 90 · 5 = 450 km."
}
],
"yt": ""
},
{
"id": "regra3",
"n": "Regra de Três",
"u": 0,
"i": "×",
"v": [
[
"Marcos Aba",
"https://www.youtube.com/results?search_query=Marcos+Aba+Regra+de+Tr%C3%AAs+ENEM"
],
[
"Ferretto Matemática",
"https://www.youtube.com/results?search_query=Ferretto+Matem%C3%A1tica+Regra+de+Tr%C3%AAs+ENEM"
]
],
"t": "<p>Relaciona quatro valores, sendo um deles desconhecido. Se as grandezas crescem juntas, a regra é <strong>direta</strong>. Se uma cresce enquanto a outra diminui, é <strong>inversa</strong>.</p><div class=\"formula\">Direta: a/b = c/x &nbsp;|&nbsp; Inversa: a·b = c·x</div>",
"o": "Decidir se é direta ou inversa. Pergunte-se: \"se uma dobra, o que acontece com a outra?\"",
"qs": [
{
"e": "6 operários constroem um muro em 10 dias. Em quantos dias 15 operários, no mesmo ritmo, constroem o mesmo muro?",
"o": [
"25 dias",
"9 dias",
"4 dias",
"16 dias"
],
"c": 2,
"d": [
"Mais operários: o tempo para terminar aumenta ou diminui?",
"Se diminui, a regra é inversa: multiplique em linha (6 · 10 = 15 · x).",
"60 = 15x. Divida os dois lados por 15."
],
"x": "<ol>\n            <li>Mais operários, menos dias: a regra é inversa.</li>\n            <li>Monte: 6 · 10 = 15 · x.</li>\n            <li>60 = 15x, logo x = 4.</li>\n          </ol><p class=\"resposta\">Resposta: 4 dias.</p>"
},
{
"e": "Cinco torneiras iguais enchem um tanque em 12 horas. Com 8 torneiras, em quanto tempo o tanque enche?",
"o": [
"6 h",
"7,5 h",
"8 h",
"19,2 h"
],
"c": 1,
"d": [],
"x": "Mais torneiras, menos tempo (inversa): 5 · 12 = 8 · x, logo x = 7,5."
},
{
"e": "10 pedreiros levantam 20 m² de parede em 6 dias. Quantos dias 15 pedreiros levam para levantar 30 m²?",
"o": [
"4",
"6",
"9",
"12"
],
"c": 1,
"d": [],
"x": "Mais área aumenta o tempo (×1,5) e mais pedreiros diminui (×2/3): 6 · 1,5 · 2/3 = 6 dias."
}
],
"yt": ""
},
{
"id": "porcentagem",
"n": "Porcentagem",
"u": 0,
"i": "%",
"v": [
[
"Marcos Aba",
"https://www.youtube.com/results?search_query=Marcos+Aba+Porcentagem+ENEM"
],
[
"Equaciona com Paulo Pereira",
"https://www.youtube.com/results?search_query=Equaciona+com+Paulo+Pereira+Porcentagem+ENEM"
]
],
"t": "<p>Porcentagem é uma fração de denominador 100. Aumentos e descontos viram multiplicações por um fator. Variações sucessivas se multiplicam, nunca se somam.</p><div class=\"formula\">p% de V = (p/100)·V &nbsp;|&nbsp; Aumento: V·(1 + i) &nbsp;|&nbsp; Desconto: V·(1 − i)</div>",
"o": "Aumentos e descontos sucessivos. Use sempre o fator multiplicativo: +20% e −20% não se anulam.",
"qs": [
{
"e": "Um produto de R$ 200 sobe 20% e depois recebe 20% de desconto. Qual é o preço final?",
"o": [
"R$ 200",
"R$ 192",
"R$ 208",
"R$ 240"
],
"c": 1,
"d": [
"Transforme +20% e −20% em fatores: 1,2 e 0,8.",
"Não some os percentuais. Multiplique o preço pelos dois fatores.",
"200 × 1,2 = 240. Depois, 240 × 0,8."
],
"x": "<ol>\n            <li>Aumento de 20%: fator 1,2.</li>\n            <li>Desconto de 20%: fator 0,8.</li>\n            <li>200 · 1,2 · 0,8 = 192.</li>\n          </ol><p class=\"resposta\">Resposta: R$ 192 (4% a menos que o original).</p>"
},
{
"e": "Uma camiseta de R$ 80,00 recebe 25% de desconto e, depois, mais 10% sobre o novo preço. Quanto passa a custar?",
"o": [
"R$ 52,00",
"R$ 54,00",
"R$ 56,00",
"R$ 62,00"
],
"c": 1,
"d": [],
"x": "80 · 0,75 · 0,90 = 54. Descontos sucessivos se multiplicam."
},
{
"e": "Um salário de R$ 2.000 teve aumento de 15%. Qual é o novo salário?",
"o": [
"R$ 2.150",
"R$ 2.300",
"R$ 2.500",
"R$ 2.030"
],
"c": 1,
"d": [],
"x": "2000 · 1,15 = 2300."
}
],
"yt": ""
},
{
"id": "estatistica",
"n": "Estatística Básica",
"u": 0,
"i": "x̄",
"v": [
[
"Ferretto Matemática",
"https://www.youtube.com/results?search_query=Ferretto+Matem%C3%A1tica+Estat%C3%ADstica+B%C3%A1sica+ENEM"
],
[
"Gis com Giz Matemática",
"https://www.youtube.com/results?search_query=Gis+com+Giz+Matem%C3%A1tica+Estat%C3%ADstica+B%C3%A1sica+ENEM"
]
],
"t": "<p><strong>Média</strong> é a soma dos valores dividida pela quantidade. <strong>Moda</strong> é o valor que mais se repete. <strong>Mediana</strong> é o valor central dos dados em ordem crescente (se a quantidade for par, é a média dos dois centrais).</p><div class=\"formula\">Média = (x₁ + x₂ + … + xₙ) / n</div>",
"o": "Comparar média, moda e mediana em tabelas e gráficos. Lembre-se de ordenar os dados antes de achar a mediana.",
"qs": [
{
"e": "As notas de um aluno foram 4, 6, 7, 8, 8 e 9. Calcule média, moda e mediana.",
"o": [
"Média 7, moda 8, mediana 7,5",
"Média 7, moda 8, mediana 8",
"Média 7,5, moda 8, mediana 7",
"Média 8, moda 8, mediana 7,5"
],
"c": 0,
"d": [
"Média: some todas as notas e divida por 6.",
"Moda: procure o número repetido. Mediana: com 6 valores, olhe o 3º e o 4º.",
"A soma é 42, e os valores centrais são 7 e 8."
],
"x": "<ol>\n            <li>Média: (4+6+7+8+8+9) / 6 = 42 / 6 = 7.</li>\n            <li>Moda: o 8 aparece duas vezes.</li>\n            <li>Mediana: os centrais são 7 e 8, então (7+8)/2 = 7,5.</li>\n          </ol><p class=\"resposta\">Resposta: média 7, moda 8, mediana 7,5.</p>"
},
{
"e": "Os valores 3, 5, 5, 7 e 10 foram observados. Quanto a média excede a mediana?",
"o": [
"0,5",
"1",
"1,5",
"2"
],
"c": 1,
"d": [],
"x": "Média = 30/5 = 6. Mediana = 5. Diferença: 1."
},
{
"e": "A média de 4 números é 10. Incluindo um quinto número, 20, qual passa a ser a média?",
"o": [
"11",
"12",
"14",
"15"
],
"c": 1,
"d": [],
"x": "Soma inicial: 40. Nova soma: 60. Média: 60/5 = 12."
}
],
"yt": ""
},
{
"id": "fracoes",
"n": "Frações",
"u": 1,
"i": "½",
"v": [
[
"Marcos Aba",
"https://www.youtube.com/results?search_query=Marcos+Aba+Fra%C3%A7%C3%B5es+ENEM"
],
[
"Matemática em Exercícios",
"https://www.youtube.com/results?search_query=Matem%C3%A1tica+em+Exerc%C3%ADcios+Fra%C3%A7%C3%B5es+ENEM"
]
],
"t": "<p>Para somar ou subtrair frações, use denominadores iguais (via MMC). Na multiplicação, multiplique numeradores e denominadores. Na divisão, multiplique pelo inverso da segunda fração.</p><div class=\"formula\">a/b + c/d = (a·d + b·c)/(b·d) &nbsp;|&nbsp; a/b ÷ c/d = a/b · d/c</div>",
"o": "\"Fração do que sobrou\". Em \"gastou 1/3 e depois 1/4 do restante\", o segundo valor se refere ao que sobrou, não ao total.",
"qs": [
{
"e": "Calcule 2/3 + 3/4.",
"o": [
"5/7",
"17/12",
"6/12",
"12/17"
],
"c": 1,
"d": [
"Para somar frações, os denominadores precisam ser iguais.",
"O MMC de 3 e 4 é 12: reescreva as frações com denominador 12.",
"2/3 = 8/12 e 3/4 = 9/12. Agora some os numeradores."
],
"x": "<ol>\n            <li>MMC de 3 e 4 é 12.</li>\n            <li>2/3 = 8/12 e 3/4 = 9/12.</li>\n            <li>8/12 + 9/12 = 17/12.</li>\n          </ol><p class=\"resposta\">Resposta: 17/12 (≈ 1,42).</p>"
},
{
"e": "Ana gastou 1/3 do salário e, do que sobrou, gastou 1/4. Que fração do salário restou?",
"o": [
"1/2",
"5/12",
"7/12",
"2/3"
],
"c": 0,
"d": [],
"x": "Sobraram 2/3; 1/4 de 2/3 = 1/6; restou 2/3 − 1/6 = 1/2."
},
{
"e": "Uma jarra com 3/4 de litro é dividida em copos de 1/8 de litro. Quantos copos?",
"o": [
"4",
"6",
"8",
"12"
],
"c": 1,
"d": [],
"x": "(3/4) ÷ (1/8) = 3/4 · 8 = 6."
}
],
"yt": ""
},
{
"id": "operacoes",
"n": "Operações e Potências",
"u": 1,
"i": "+",
"v": [
[
"Ferretto Matemática",
"https://www.youtube.com/results?search_query=Ferretto+Matem%C3%A1tica+Opera%C3%A7%C3%B5es+e+Pot%C3%AAncias+ENEM"
],
[
"Matemática em Exercícios",
"https://www.youtube.com/results?search_query=Matem%C3%A1tica+em+Exerc%C3%ADcios+Opera%C3%A7%C3%B5es+e+Pot%C3%AAncias+ENEM"
]
],
"t": "<p>Ordem das operações: parênteses, potências e raízes, multiplicação e divisão, e por fim soma e subtração. Propriedades das potências simplificam contas grandes e a notação científica.</p><div class=\"formula\">aᵐ·aⁿ = aᵐ⁺ⁿ &nbsp;|&nbsp; (aᵐ)ⁿ = aᵐ·ⁿ &nbsp;|&nbsp; a⁻ⁿ = 1/aⁿ</div>",
"o": "Notação científica (ex.: 3,2 × 10⁵) em contextos reais, como distâncias, populações e tamanhos de vírus.",
"qs": [
{
"e": "Calcule 2 + 3 × (8 − 2)² ÷ 4.",
"o": [
"29",
"45",
"22",
"54"
],
"c": 0,
"d": [
"Comece pelo que está entre parênteses.",
"Depois a potência; só então multiplicação e divisão, da esquerda para a direita.",
"(8−2)² = 36, depois 3 × 36 = 108, depois 108 ÷ 4 = 27."
],
"x": "<ol>\n            <li>Parênteses: 8 − 2 = 6.</li>\n            <li>Potência: 6² = 36.</li>\n            <li>Multiplicação e divisão, da esquerda para a direita: 3 × 36 = 108 e 108 ÷ 4 = 27.</li>\n            <li>Soma: 2 + 27 = 29.</li>\n          </ol><p class=\"resposta\">Resposta: 29.</p>"
},
{
"e": "Um vírus pesa 2 × 10⁻⁶ g. Qual o peso de 5 × 10⁹ deles?",
"o": [
"1.000 g",
"10.000 g",
"7.000 g",
"100.000 g"
],
"c": 1,
"d": [],
"x": "(2 · 5) × 10⁻⁶⁺⁹ = 10 × 10³ = 10.000 g."
},
{
"e": "Qual o valor de 2³ · 2⁴ ÷ 2⁵?",
"o": [
"2",
"4",
"8",
"16"
],
"c": 1,
"d": [],
"x": "Some e subtraia os expoentes: 3 + 4 − 5 = 2, então 2² = 4."
}
],
"yt": ""
},
{
"id": "mmc",
"n": "MMC e MDC",
"u": 1,
"i": "∞",
"v": [
[
"Marcos Aba",
"https://www.youtube.com/results?search_query=Marcos+Aba+MMC+e+MDC+ENEM"
],
[
"Matemática em Exercícios",
"https://www.youtube.com/results?search_query=Matem%C3%A1tica+em+Exerc%C3%ADcios+MMC+e+MDC+ENEM"
]
],
"t": "<p>Fatore os números em primos. O <strong>MMC</strong> usa todos os fatores com o maior expoente. O <strong>MDC</strong> usa só os fatores comuns com o menor expoente.</p><div class=\"formula\">MMC = menor múltiplo comum &nbsp;|&nbsp; MDC = maior divisor comum</div>",
"o": "Eventos que se repetem juntos pedem MMC. Dividir em grupos iguais, do maior tamanho possível, pede MDC.",
"qs": [
{
"e": "Dois ônibus saem juntos às 6h. Um passa a cada 12 min e o outro a cada 18 min. Quando saem juntos de novo?",
"o": [
"6 min",
"24 min",
"36 min",
"216 min"
],
"c": 2,
"d": [
"Os ônibus se encontram quando o tempo é múltiplo de 12 e de 18 ao mesmo tempo.",
"Procure o menor múltiplo comum: fatore 12 e 18.",
"12 = 2²·3 e 18 = 2·3². Pegue os maiores expoentes: 4 · 9."
],
"x": "<ol>\n            <li>Fatore: 12 = 2²·3 e 18 = 2·3².</li>\n            <li>MMC = 2²·3² = 36.</li>\n          </ol><p class=\"resposta\">Resposta: após 36 min, às 6h36. (O MDC seria 2·3 = 6.)</p>"
},
{
"e": "Três luzes piscam a cada 4 s, 6 s e 10 s. Depois de quantos segundos piscam juntas de novo?",
"o": [
"20",
"30",
"60",
"120"
],
"c": 2,
"d": [],
"x": "MMC(4, 6, 10) = 2² · 3 · 5 = 60."
},
{
"e": "Dois rolos de fita medem 48 m e 60 m. Cortados em pedaços iguais, do maior tamanho possível e sem sobras, cada pedaço mede:",
"o": [
"6 m",
"12 m",
"24 m",
"240 m"
],
"c": 1,
"d": [],
"x": "MDC(48, 60) = 12."
}
],
"yt": ""
},
{
"id": "areas",
"n": "Áreas de Figuras Planas",
"u": 2,
"i": "▲",
"v": [
[
"Ferretto Matemática",
"https://www.youtube.com/results?search_query=Ferretto+Matem%C3%A1tica+%C3%81reas+de+Figuras+Planas+ENEM"
],
[
"Equaciona com Paulo Pereira",
"https://www.youtube.com/results?search_query=Equaciona+com+Paulo+Pereira+%C3%81reas+de+Figuras+Planas+ENEM"
]
],
"t": "<div class=\"formula\">Retângulo: b·h &nbsp;|&nbsp; Triângulo: b·h/2 &nbsp;|&nbsp; Trapézio: (B + b)·h/2</div><div class=\"formula\">Círculo: π·r² &nbsp;|&nbsp; Losango: D·d/2 &nbsp;|&nbsp; Quadrado: l²</div>",
"o": "Figuras compostas: divida em formas conhecidas ou subtraia uma da outra. Atenção às unidades (1 m² = 10.000 cm²).",
"qs": [
{
"e": "Um terreno trapezoidal tem bases de 20 m e 12 m e altura de 10 m. Qual é a área?",
"o": [
"320 m²",
"160 m²",
"240 m²",
"80 m²"
],
"c": 1,
"d": [
"Qual é a forma do terreno? Lembre a fórmula dessa figura.",
"Some as duas bases antes de multiplicar pela altura.",
"20 + 12 = 32; 32 · 10 = 320; divida por 2."
],
"x": "<ol>\n            <li>Aplique (B + b)·h/2.</li>\n            <li>(20 + 12) · 10 / 2 = 320 / 2 = 160.</li>\n          </ol><p class=\"resposta\">Resposta: 160 m².</p>"
},
{
"e": "Um jardim circular tem raio de 3 m. Qual é a área? (use π = 3)",
"o": [
"18 m²",
"27 m²",
"9 m²",
"54 m²"
],
"c": 1,
"d": [],
"x": "π · r² = 3 · 9 = 27."
},
{
"e": "Um painel triangular tem base de 10 cm e altura de 6 cm. Qual é a área?",
"o": [
"16 cm²",
"30 cm²",
"60 cm²",
"15 cm²"
],
"c": 1,
"d": [],
"x": "b · h / 2 = 10 · 6 / 2 = 30."
}
],
"yt": ""
},
{
"id": "pitagoras",
"n": "Teorema de Pitágoras",
"u": 2,
"i": "a²",
"v": [
[
"Ferretto Matemática",
"https://www.youtube.com/results?search_query=Ferretto+Matem%C3%A1tica+Teorema+de+Pit%C3%A1goras+ENEM"
],
[
"Matemática Rio",
"https://www.youtube.com/results?search_query=Matem%C3%A1tica+Rio+Teorema+de+Pit%C3%A1goras+ENEM"
]
],
"t": "<p>Em todo triângulo retângulo, o quadrado da hipotenusa (lado oposto ao ângulo reto) é igual à soma dos quadrados dos catetos.</p><div class=\"formula\">a² = b² + c²</div>",
"o": "Decore os trios 3-4-5 e 5-12-13. A diagonal de um quadrado de lado l mede l√2.",
"qs": [
{
"e": "Uma escada de 5 m está apoiada em uma parede, com a base a 3 m dela. Qual a altura atingida?",
"o": [
"2 m",
"4 m",
"5,8 m",
"8 m"
],
"c": 1,
"d": [
"Desenhe um triângulo retângulo. Qual lado é a hipotenusa?",
"A escada é a hipotenusa (5 m) e a base é um cateto (3 m).",
"25 = 9 + h², então h² = 16."
],
"x": "<ol>\n            <li>A escada é a hipotenusa: 5² = 3² + h².</li>\n            <li>25 = 9 + h², então h² = 16.</li>\n            <li>h = 4.</li>\n          </ol><p class=\"resposta\">Resposta: 4 m.</p>"
},
{
"e": "Uma tela retangular mede 12 cm por 16 cm. Quanto mede a diagonal?",
"o": [
"18 cm",
"20 cm",
"22 cm",
"28 cm"
],
"c": 1,
"d": [],
"x": "d² = 12² + 16² = 400, então d = 20."
},
{
"e": "Um fio de 13 m vai do topo de um poste até o chão, a 5 m da base. Qual a altura do poste?",
"o": [
"8 m",
"12 m",
"14 m",
"18 m"
],
"c": 1,
"d": [],
"x": "13² = 5² + h², então h² = 144 e h = 12."
}
],
"yt": ""
},
{
"id": "espacial",
"n": "Geometria Espacial",
"u": 2,
"i": "🧊",
"v": [
[
"Ferretto Matemática",
"https://www.youtube.com/results?search_query=Ferretto+Matem%C3%A1tica+Geometria+Espacial+ENEM"
],
[
"Gis com Giz Matemática",
"https://www.youtube.com/results?search_query=Gis+com+Giz+Matem%C3%A1tica+Geometria+Espacial+ENEM"
]
],
"t": "<div class=\"formula\">Prisma e cilindro: V = Ab · h</div><div class=\"formula\">Pirâmide e cone: V = Ab · h / 3</div><div class=\"formula\">Esfera: V = (4/3)·π·r³ &nbsp;|&nbsp; Área = 4·π·r²</div>",
"o": "Conversão entre volume e capacidade: 1 dm³ = 1 litro e 1 m³ = 1.000 litros. Pense também em volume de líquido que muda de recipiente.",
"qs": [
{
"e": "Uma lata cilíndrica tem raio de 5 cm e altura de 10 cm. Qual é o volume? (use π = 3,14)",
"o": [
"78,5 cm³",
"250 cm³",
"785 cm³",
"1.570 cm³"
],
"c": 2,
"d": [
"Cilindro: volume = área da base × altura.",
"A base é um círculo: π · r², com r = 5.",
"3,14 · 25 = 78,5. Multiplique por 10."
],
"x": "<ol>\n            <li>Área da base: π·r² = 3,14 · 25 = 78,5 cm².</li>\n            <li>Volume: 78,5 · 10 = 785 cm³.</li>\n          </ol><p class=\"resposta\">Resposta: 785 cm³ (cerca de 0,785 litro).</p>"
},
{
"e": "Qual a capacidade, em litros, de uma caixa-d'água cúbica de aresta 1,5 m?",
"o": [
"2.250 L",
"3.375 L",
"4.500 L",
"6.750 L"
],
"c": 1,
"d": [],
"x": "V = 1,5³ = 3,375 m³, e 1 m³ = 1.000 L."
},
{
"e": "Qual é o volume de uma esfera de raio 3 cm?",
"o": [
"12π cm³",
"36π cm³",
"27π cm³",
"108π cm³"
],
"c": 1,
"d": [],
"x": "(4/3) · π · 3³ = (4/3) · 27π = 36π."
}
],
"yt": ""
},
{
"id": "funcao1",
"n": "Função do 1º Grau",
"u": 3,
"i": "ƒ",
"v": [
[
"Gis com Giz Matemática",
"https://www.youtube.com/results?search_query=Gis+com+Giz+Matem%C3%A1tica+Fun%C3%A7%C3%A3o+do+1%C2%BA+Grau+ENEM"
],
[
"Ferretto Matemática",
"https://www.youtube.com/results?search_query=Ferretto+Matem%C3%A1tica+Fun%C3%A7%C3%A3o+do+1%C2%BA+Grau+ENEM"
]
],
"t": "<p>O gráfico é uma reta. O coeficiente <strong>a</strong> é a taxa de variação (quanto muda a cada unidade de x) e <strong>b</strong> é o valor inicial.</p><div class=\"formula\">f(x) = a·x + b &nbsp;|&nbsp; Raiz: x = −b/a</div>",
"o": "Montar a função a partir do texto. \"Valor fixo + valor por unidade\" é quase sempre ax + b.",
"qs": [
{
"e": "Um táxi cobra R$ 5 de bandeirada mais R$ 2 por km. Quanto custa uma corrida de 12 km?",
"o": [
"R$ 24",
"R$ 29",
"R$ 34",
"R$ 60"
],
"c": 1,
"d": [
"Separe o valor fixo (b) do valor que varia por km (a).",
"Monte f(x) = 2x + 5, em que x é o número de km.",
"Substitua x por 12."
],
"x": "<ol>\n            <li>Modelo: f(x) = 2x + 5.</li>\n            <li>f(12) = 2 · 12 + 5 = 29.</li>\n          </ol><p class=\"resposta\">Resposta: R$ 29.</p>"
},
{
"e": "Para f(x) = 3x − 6, em que valor de x a função se anula?",
"o": [
"−2",
"2",
"3",
"6"
],
"c": 1,
"d": [],
"x": "3x − 6 = 0 → x = 2."
},
{
"e": "Um plano custa R$ 30 fixos mais R$ 0,50 por GB. Com quantos GB a conta chega a R$ 45?",
"o": [
"15",
"30",
"60",
"90"
],
"c": 1,
"d": [],
"x": "30 + 0,5x = 45, então x = 30."
}
],
"yt": ""
},
{
"id": "funcao2",
"n": "Função do 2º Grau",
"u": 3,
"i": "∪",
"v": [
[
"Ferretto Matemática",
"https://www.youtube.com/results?search_query=Ferretto+Matem%C3%A1tica+Fun%C3%A7%C3%A3o+do+2%C2%BA+Grau+ENEM"
],
[
"Equaciona com Paulo Pereira",
"https://www.youtube.com/results?search_query=Equaciona+com+Paulo+Pereira+Fun%C3%A7%C3%A3o+do+2%C2%BA+Grau+ENEM"
]
],
"t": "<p>O gráfico é uma parábola. Se a &gt; 0, abre para cima (tem mínimo). Se a &lt; 0, abre para baixo (tem máximo). O ponto de máximo ou mínimo é o vértice.</p><div class=\"formula\">f(x) = ax² + bx + c &nbsp;|&nbsp; Δ = b² − 4ac &nbsp;|&nbsp; x = (−b ± √Δ) / 2a</div><div class=\"formula\">Vértice: x<sub>v</sub> = −b / 2a &nbsp;|&nbsp; y<sub>v</sub> = −Δ / 4a</div>",
"o": "Problemas de máximo e mínimo (lucro, altura, área). Se a pergunta é \"qual o maior valor?\", o caminho é o vértice.",
"qs": [
{
"e": "A altura (em metros) de uma bola é h(t) = −t² + 6t, com t em segundos. Qual é a altura máxima?",
"o": [
"3 m",
"6 m",
"9 m",
"18 m"
],
"c": 2,
"d": [
"Com a < 0, o máximo da parábola está no vértice.",
"Calcule o t do vértice: −b / 2a, com a = −1 e b = 6.",
"t = 3. Agora calcule h(3) = −3² + 6 · 3."
],
"x": "<ol>\n            <li>Como a = −1 &lt; 0, existe um máximo no vértice.</li>\n            <li>t<sub>v</sub> = −6 / (2 · (−1)) = 3 s.</li>\n            <li>h(3) = −9 + 18 = 9.</li>\n          </ol><p class=\"resposta\">Resposta: 9 m, após 3 s.</p>"
},
{
"e": "O lucro de uma loja é L(x) = −x² + 10x − 16. Qual é o lucro máximo?",
"o": [
"5",
"9",
"16",
"25"
],
"c": 1,
"d": [],
"x": "x do vértice = 5 e L(5) = −25 + 50 − 16 = 9."
},
{
"e": "Quais são as raízes de x² − 5x + 6 = 0?",
"o": [
"1 e 6",
"2 e 3",
"−2 e −3",
"−1 e 6"
],
"c": 1,
"d": [],
"x": "Δ = 25 − 24 = 1, então x = (5 ± 1) / 2, ou seja, 2 e 3."
}
],
"yt": ""
},
{
"id": "exponencial",
"n": "Função Exponencial",
"u": 3,
"i": "eˣ",
"v": [
[
"Matemática Rio",
"https://www.youtube.com/results?search_query=Matem%C3%A1tica+Rio+Fun%C3%A7%C3%A3o+Exponencial+ENEM"
],
[
"Ferretto Matemática",
"https://www.youtube.com/results?search_query=Ferretto+Matem%C3%A1tica+Fun%C3%A7%C3%A3o+Exponencial+ENEM"
]
],
"t": "<p>A variável fica no expoente. Modela crescimentos e decaimentos proporcionais, como juros compostos, populações e decaimento radioativo.</p><div class=\"formula\">f(x) = aˣ (a &gt; 0, a ≠ 1) &nbsp;|&nbsp; Montante: M = C · (1 + i)ᵗ</div>",
"o": "Juros compostos e crescimento populacional. Se há \"taxa por período\" aplicada repetidamente, é exponencial.",
"qs": [
{
"e": "R$ 1.000 são aplicados a 10% ao mês, juros compostos. Qual o montante após 2 meses?",
"o": [
"R$ 1.200",
"R$ 1.210",
"R$ 1.100",
"R$ 2.000"
],
"c": 1,
"d": [
"Juros compostos: M = C · (1 + i)ᵗ.",
"Aqui C = 1000, i = 0,10 e t = 2.",
"1,1² = 1,21. Multiplique por 1000."
],
"x": "<ol>\n            <li>M = 1000 · (1,1)².</li>\n            <li>(1,1)² = 1,21.</li>\n            <li>M = 1000 · 1,21 = 1210.</li>\n          </ol><p class=\"resposta\">Resposta: R$ 1.210.</p>"
},
{
"e": "Uma cultura começa com 100 bactérias, que dobram a cada hora. Quantas há após 5 horas?",
"o": [
"500",
"1.600",
"3.200",
"10.000"
],
"c": 2,
"d": [],
"x": "100 · 2⁵ = 3.200."
},
{
"e": "Um carro de R$ 40.000 desvaloriza 10% ao ano. Quanto vale após 2 anos?",
"o": [
"R$ 32.000",
"R$ 32.400",
"R$ 36.000",
"R$ 30.000"
],
"c": 1,
"d": [],
"x": "40000 · 0,9² = 32400."
}
],
"yt": ""
},
{
"id": "logaritmo",
"n": "Logaritmos",
"u": 3,
"i": "log",
"v": [
[
"Ferretto Matemática",
"https://www.youtube.com/results?search_query=Ferretto+Matem%C3%A1tica+Logaritmos+ENEM"
],
[
"Matemática em Exercícios",
"https://www.youtube.com/results?search_query=Matem%C3%A1tica+em+Exerc%C3%ADcios+Logaritmos+ENEM"
]
],
"t": "<p>O logaritmo responde: \"a qual expoente devo elevar a base para obter o número?\". É a operação inversa da exponencial.</p><div class=\"formula\">log<sub>b</sub> a = x ⇔ bˣ = a</div><div class=\"formula\">log(a·b) = log a + log b &nbsp;|&nbsp; log(a/b) = log a − log b &nbsp;|&nbsp; log aⁿ = n · log a</div>",
"o": "A prova fornece os valores dos logaritmos. Seu trabalho é isolar o expoente com a propriedade log aⁿ = n · log a.",
"qs": [
{
"e": "Em quantos meses R$ 1.000 viram R$ 2.000 a 10% ao mês? (dados: log 2 = 0,301 e log 1,1 = 0,041)",
"o": [
"2 meses",
"5 meses",
"7,3 meses",
"10 meses"
],
"c": 2,
"d": [
"Primeiro isole a potência: (1,1)ᵗ = 2.",
"Aplique log nos dois lados e use log aⁿ = n · log a.",
"t = log 2 ÷ log 1,1 = 0,301 ÷ 0,041."
],
"x": "<ol>\n            <li>Monte: 1000 · (1,1)ᵗ = 2000, logo (1,1)ᵗ = 2.</li>\n            <li>Aplique log: t · log 1,1 = log 2.</li>\n            <li>t = 0,301 / 0,041 ≈ 7,3.</li>\n          </ol><p class=\"resposta\">Resposta: cerca de 7,3 meses.</p>"
},
{
"e": "Quanto vale log₂ 32?",
"o": [
"4",
"5",
"16",
"30"
],
"c": 1,
"d": [],
"x": "2⁵ = 32, então log₂ 32 = 5."
},
{
"e": "Dado log 2 = 0,3, quanto vale log 8?",
"o": [
"0,6",
"0,9",
"2,4",
"3"
],
"c": 1,
"d": [],
"x": "log 8 = log 2³ = 3 · 0,3 = 0,9."
}
],
"yt": ""
}
];
